cd /Users/LazyRen/GoogleDrive/3-1/운영체제/os2018/proj_scheduler/xv6-public
make TOOLPREFIX=i386-elf- CPUS=1 qemu-nox

